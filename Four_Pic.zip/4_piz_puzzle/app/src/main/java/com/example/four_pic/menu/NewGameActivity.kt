package com.example.four_pic.menu

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.AppCompatButton
import androidx.core.view.isVisible
import com.example.four_pic.R
import com.example.four_pic.app.MyService
import com.example.four_pic.databinding.ActivityContinueBinding
import com.example.four_pic.manager.GameManager
import com.example.four_pic.models.QuestionData
import com.example.four_pic.utils.*

class NewGameActivity : AppCompatActivity() {
    private lateinit var binding: ActivityContinueBinding
    private lateinit var questionsList: ArrayList<QuestionData>
    private lateinit var imagesList: ArrayList<ImageView>
    private lateinit var wordList: ArrayList<Button>
    private lateinit var lettersList: ArrayList<Button>
    private lateinit var gameManager: GameManager
    private lateinit var userName : TextView
    private var wordCheck = ""
    lateinit var dialog:Dialog
    private val shared by lazy {
        SharedPreferencesHelper(this)
    }
    var wordSize = 0
    var letterSize =0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityContinueBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener {
            val intent = Intent(this, MenuActivity::class.java)
            startActivity(intent)
            finish()
        }
        val userNAME = shared.getUserName()
        userName = findViewById(R.id.userNameID)
        userName.text=userNAME.toString()
        getAllQuestions()
        gameManager = GameManager(questionsList, 0, 0)
        loadViews()
        binding.level.text=(gameManager.level+1).toString()
        binding.coins.text =gameManager.coins.toString()
        loadDataToView()
        binding.btnClean.setOnClickListener {
            for (i in 0 until wordList.size){
                wordList[i].text=""
                letterSize=0
            }
            for (i in 0 until lettersList.size) {
                lettersList[i].visible()
            }
            wordCheck=""
        }
        binding.btnHelp.setOnClickListener {
            if (gameManager.coins>=5) {
                var n = 0
                for (i in 0 until wordList.size) {
                    n = i
                    if (wordList[i].text.isEmpty()) {
                        wordList[n].text = gameManager.getWord()[n].toString()
                        break
                    }
                }
                for (i in 0 until lettersList.size) {
                    if (lettersList[i].text.toString() == wordList[n].text.toString()) {
                        lettersList[i].invisible()
                        break
                    }
                }
                letterSize++
                binding.coins.text = gameManager.coins.toString()
                if (letterSize==wordSize){
                    if (!gameManager.hasNextQuestion()) {
                        custom()
                    }else{
                        if (check_()) {
                            Toast.makeText(this, "Correct!", Toast.LENGTH_LONG).show()
                            Thread.sleep(500)
                            gameManager.coins += 10
                            binding.coins.text = gameManager.coins.toString()
                            gameManager.level++
                            var level_ = gameManager.level
                            shared.setCoin(gameManager.coins)
                            binding.level.text = (++level_).toString()
                            getAllQuestions()
                            shared.setLevel(gameManager.level)
                            loadDataToView()
                            wordCheck = ""
                            letterSize=0
                            wordSize = gameManager.getWord().length

                        }
                    }
                }
                gameManager.coins-=5
                binding.coins.text = gameManager.coins.toString()
            }else{
                dialog= Dialog(this)
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
                dialog.setContentView(R.layout.dialog_coins)
                dialog.setCancelable(true)
                dialog.window!!.attributes.windowAnimations=R.style.DialogAnimation
                val button=dialog.findViewById<AppCompatButton>(R.id.coins_okay)
                button.setOnClickListener {
                    dialog.cancel()
                }
                dialog.show()
            }
        }
    }
    override fun onStop() {
        shared.setLevel(gameManager.level)
        shared.setCoin(gameManager.coins)
        super.onStop()
    }

    private fun startTimer() {
        object : CountDownTimer(3000, 2000) {
            override fun onFinish() {
//                startActivity(Intent(this@MainActivity, MenuActivity::class.java))
            }
            override fun onTick(millisUntilFinished: Long) {
            }
        }.start()
    }

    private fun custom() {
        val alertDialog: AlertDialog.Builder = AlertDialog.Builder(this@NewGameActivity,
            R.style.fullScreenAlert
        )
        val view: View = layoutInflater.inflate(R.layout.dialog_win, null)
        var goToMenu = findViewById<Button>(R.id.go_to_menu)
        goToMenu.setOnClickListener {
            startActivity(Intent(this, MenuActivity::class.java))
        }
        alertDialog.setView(view)
        val dialog = alertDialog.create()
        dialog.show()
    }

    private fun getAllQuestions() {
        questionsList = ArrayList()
        questionsList.add(
            QuestionData(
                arrayListOf(
                    R.drawable.img1,
                    R.drawable.img2,
                    R.drawable.img3,
                    R.drawable.img4,
                ),
                "bridge",
                "blrfghedoi"
            )
        )
        questionsList.add(
            QuestionData(
                arrayListOf(
                    R.drawable.img5,
                    R.drawable.img6,
                    R.drawable.img7,
                    R.drawable.img8,
                ),
                "card",
                "ctajldsrom"
            )
        )
        questionsList.add(
            QuestionData(
                arrayListOf(
                    R.drawable.img9,
                    R.drawable.img10,
                    R.drawable.img11,
                    R.drawable.img12,
                ),
                "water",
                "rwqtoanyek"
            )
        )
        questionsList.add(
            QuestionData(
                arrayListOf(
                    R.drawable.img13,
                    R.drawable.img14,
                    R.drawable.img15,
                    R.drawable.img16,
                ),
                "old",
                "lwqtoanydk"
            )
        )
        questionsList.add(
            QuestionData(
                arrayListOf(
                    R.drawable.img17,
                    R.drawable.img18,
                    R.drawable.img19,
                    R.drawable.img21, // img20
                ),
                "yellow",
                "lwltoanyke"
            )
        )
        questionsList.add(
            QuestionData(
                arrayListOf(
                    R.drawable.img21,
                    R.drawable.img22, // img22
                    R.drawable.img23,
                    R.drawable.img24, // img23
                ),
                "clock",
                "cwltoanykc"
            )
        )
        questionsList.add(
            QuestionData(
                arrayListOf(
                    R.drawable.img25,
                    R.drawable.img26, // img26
                    R.drawable.img27,
                    R.drawable.img28,
                ),
                "back",
                "cwlboanykc"
            )
        )
        questionsList.add(
            QuestionData(
                arrayListOf(
                    R.drawable.img30, // img29
                    R.drawable.img31,
                    R.drawable.img32, // img31
                    R.drawable.img33,
                ),
                "mouse",
                "eulboanyms"
            )
        )
    }

    private fun loadViews() {
        imagesList = ArrayList()
        for (i in 0 until binding.imagesLayout.childCount) {
            imagesList.add(binding.imagesLayout.getChildAt(i) as ImageView)
        }
        /////////
        wordList = ArrayList()
        for (i in 0 until binding.wordLayout.childCount) {
            wordList.add(binding.wordLayout.getChildAt(i) as Button)
            wordList[i].setOnClickListener {

                wordBtnClick(it as Button)
            }
        }
        ///////////
        lettersList = ArrayList()
        for (i in 0 until binding.letterLayout.childCount) {
            lettersList.add(binding.letterLayout.getChildAt(i) as Button)
            lettersList[i].setOnClickListener {
                letterBtnClick(it as Button)
                wordSize = gameManager.getWordSize()
                letterSize++
                if (letterSize==wordSize){
                    if (!gameManager.hasNextQuestion()) {
                        custom()
                    }else{
                        if (check_()) {
                            Toast.makeText(this, "Correct!", Toast.LENGTH_LONG).show()
                            Thread.sleep(500)
                            gameManager.coins += 10
                            binding.coins.text = gameManager.coins.toString()

                            gameManager.level++

                            var level_ = gameManager.level
                            shared.setCoin(gameManager.coins)
                            binding.level.text = (++level_).toString()
                            getAllQuestions()
                            shared.setLevel(gameManager.level)
                            loadDataToView()
                            wordCheck = ""
                            letterSize=0
                            wordSize = gameManager.getWord().length
                        } else {
                            Toast.makeText(this, "Incorrect", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }
    }

    private fun letterBtnClick(button: Button) {
        if (button.isVisible && wordList[gameManager.getWordSize()-1].text.isEmpty()) {
            button.invisible()
            val word = button.text.toString()
            for (i in 0 until wordList.size) {
                if (wordList[i].text.isEmpty()) {
                    wordList[i].text = word
                    break
                }
            }
        }
    }

    fun check_(): Boolean {
        for (i in 0 until (gameManager.getWordSize())){
            wordCheck+=wordList[i].text.toString()
        }
        return gameManager.check(wordCheck)
    }

    private fun wordBtnClick(it: Button) {
        if (it.text.isNotEmpty()) {
            val word = it.text.toString()
            it.text = ""
            for (i in 0 until lettersList.size) {
                if (lettersList[i].isInvisible()
                    && lettersList[i].text.toString().lowercase() == word.lowercase()
                ) {
                    lettersList[i].visible()
                    wordCheck+=word
                    print(wordCheck)
                    break
                }
            }
            for (i in 0 until wordList.size){
                if(wordList[i].text.isNotEmpty()){
                    wordCheck+=wordList[i].toString()
                }else wordCheck=""
            }
        }
        wordCheck = ""
    }

    private fun loadDataToView() {
        for (i in 0 until imagesList.size) {
            imagesList[i].setImageResource(gameManager.getQuestions()[i])
        }
        /////////
        for (i in 0 until wordList.size) {
            if (gameManager.getWordSize() > i) {
                wordList[i].visible()
                wordList[i].text = ""
            } else {
                wordList[i].gone()
            }
        }
        ////////
        for (i in 0 until lettersList.size) {
            lettersList[i].visible()
            lettersList[i].text = gameManager.getLetters()[i].toString()
        }
    }
    override fun onPause() {
        super.onPause()
        stopService(Intent(this, MyService::class.java)) // остановить песню
    }

    // развернули приложение
    override fun onResume() {
        super.onResume()
        startService(Intent(this, MyService::class.java)) // запустить песню
    }

}