package com.example.four_pic.menu;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Switch;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.example.four_pic.R;
import com.example.four_pic.app.MyService;
import com.example.four_pic.manager.LanguageManager;
import com.example.four_pic.utils.SharedPreferencesHelper;


public class SettingsActivity extends AppCompatActivity {
//    Switch volume_sw;
    AppCompatButton eng;
    AppCompatButton uz;
    AppCompatButton ru;
    LanguageManager languageManager;
    Intent intent;
    ImageButton settings_to_menu;
    SharedPreferencesHelper sharedPreferencesHelper;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        initViews();
//        volume_sw.setOnClickListener(view -> {
//            if (volume_sw.isChecked()){
//                startService(new Intent(getApplicationContext(), MyService.class));
//
//
//            }else {
//                stopService(new Intent(getApplicationContext(), MyService.class));
//
//            }
//        });
        ru.setOnClickListener(view -> {
            languageManager.updateResourse("ru");
            recreate();
            startActivity(intent);
            finish();
        });
        uz.setOnClickListener(view -> {
            languageManager.updateResourse("uz");
            recreate();
            startActivity(intent);
            finish();
        });
        eng.setOnClickListener(view -> {
            languageManager.updateResourse("eng");
            recreate();
            startActivity(intent);
            finish();
        });
        settings_to_menu.setOnClickListener(view -> {
            startActivity(intent);
            finish();
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopService(new Intent(getApplicationContext(), MyService.class));
    }

    @Override
    protected void onResume() {
        super.onResume();
        startService(new Intent(getApplicationContext(), MyService.class));
    }

    public void initViews(){
//        volume_sw = findViewById(R.id.volume_music);
        eng = findViewById(R.id.eng);
        uz = findViewById(R.id.uzb);
        ru = findViewById(R.id.ru);
        languageManager = new LanguageManager(SettingsActivity.this);
        intent = new Intent(getApplicationContext(), MenuActivity.class);
        settings_to_menu = findViewById(R.id.settings_to_menu);
        sharedPreferencesHelper = new SharedPreferencesHelper(this);
    }


}
