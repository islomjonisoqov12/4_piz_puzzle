package com.example.four_pic.models

data class QuestionData(
    var imageList: ArrayList<Int>,
    var word: String,
    var letters: String
)